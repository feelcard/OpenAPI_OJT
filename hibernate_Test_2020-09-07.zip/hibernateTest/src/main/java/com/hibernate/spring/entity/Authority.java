package com.hibernate.spring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity(name = "authority")
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Authority {
  @Id
  @Column
  private String code;
  @Column
  private String name;
  @Column
  private String createBy;
  @Column
  private String createDate;
  @Column
  private String updateBy;
  @Column
  private String updateDate;
  @Column
  private String delete;
  // @ManyToMany(mappedBy = "auths")
  // private List<Display> displays = new ArrayList<>();

}

package com.hibernate.spring.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="MEMBER")
public class Member {
	@Column(columnDefinition = "VARCHAR(100)", name = "member_id")
	private String id;
	@Column(columnDefinition = "VARCHAR(30)", name = "member_name")
	private String name;
	@Column(columnDefinition = "VARCHAR(30)", name = "member_status")
	private String status;
	@Column(columnDefinition = "VARCHAR(200)", name = "member_url")
	private String url;
	@Column(columnDefinition = "VARCHAR(30)", name = "member_create_by")
	private String createBy;
	@Column(columnDefinition = "VARCHAR(30)", name = "member_create_date")
	private String createDate;
	@Column(columnDefinition = "VARCHAR(30)", name = "member_update_by")
	private String updateBy;
	@Column(columnDefinition = "VARCHAR(30)", name = "member_update_date")
	private String updateDate;
	@Column(columnDefinition = "VARCHAR(1)", name = "member_delete")
	private String delete;
}

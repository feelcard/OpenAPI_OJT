package hibernateTest;



public class DaoTest {

}
